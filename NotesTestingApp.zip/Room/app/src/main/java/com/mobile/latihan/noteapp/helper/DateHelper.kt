package com.mobile.latihan.noteapp.helper

import android.os.Build
import androidx.annotation.RequiresApi
import java.text.SimpleDateFormat
import java.util.*

object DateHelper {
    @RequiresApi(Build.VERSION_CODES.N)
    fun getCurrentDate(): String {
        val dateFormat = SimpleDateFormat("MM/dd/yyyy ss:mm:hh", Locale.getDefault())
        val date = Date()
        return dateFormat.format(date)
    }
}