package com.mobile.latihan.noteapp.ui.darkmode

import androidx.lifecycle.*
import kotlinx.coroutines.launch
import java.util.*

class MyViewModel(private val prefs: SettingPref) : ViewModel() {
    fun getThemeSettings(): LiveData<Boolean> {
        return prefs.getThemeSetting().asLiveData()
    }

    fun saveThemeSetting(isDarkmode: Boolean) {
        viewModelScope.launch {
            prefs.saveThemeSetting(isDarkmode)
        }
    }
}