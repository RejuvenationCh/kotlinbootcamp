package com.mobile.latihan.noteapp.ui.main

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.CompoundButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.view.menu.ActionMenuItemView
import androidx.datastore.core.DataStore
import androidx.datastore.dataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.switchmaterial.SwitchMaterial
import com.mobile.latihan.noteapp.R
import com.mobile.latihan.noteapp.databinding.ActivityMainBinding
import com.mobile.latihan.noteapp.helper.ViewModelFactory
import com.mobile.latihan.noteapp.ui.darkmode.MyViewModel
import com.mobile.latihan.noteapp.ui.darkmode.SettingPref
import com.mobile.latihan.noteapp.insert.NoteAddUpdateActivity

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")
class MainActivity : AppCompatActivity() {

    private var _activityMainBinding: ActivityMainBinding? = null
    private val binding get() = _activityMainBinding

    private lateinit var adapter: NoteAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        _activityMainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding?.root)

        val mainViewModel = obtainViewModel(this@MainActivity)
        mainViewModel.getAllNotes().observe(this) { noteList ->
            if (noteList != null) {
                adapter.setListNotes(noteList)
            }
        }

        adapter = NoteAdapter()
        binding?.rvNotes?.layoutManager = LinearLayoutManager(this)
        binding?.rvNotes?.setHasFixedSize(true)
        binding?.rvNotes?.adapter = adapter
        binding?.fabAdd?.setOnClickListener { view ->
            if (view.id == R.id.fab_add) {
                val intent = Intent(this@MainActivity, NoteAddUpdateActivity::class.java)
                startActivity(intent)
            }
        }
    }

    private fun obtainViewModel(activity: AppCompatActivity): MainViewModel {
        val factory = ViewModelFactory.getInstance(activity.application)
        return ViewModelProvider(activity, factory)[MainViewModel::class.java]
    }
    override fun onDestroy() {
        super.onDestroy()
        _activityMainBinding = null
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.actionbar, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.lightbulb -> {
                var darkorlight = 10
                val pref = SettingPref.getInstance(dataStore)
                val viewmodels =
                    ViewModelProvider(
                        this,
                        com.mobile.latihan.noteapp.ui.darkmode.ViewModelFactory(pref)
                    ).get(MyViewModel::class.java)
                viewmodels.getThemeSettings().observe(this) { isDarkMode: Boolean ->
                    if (darkorlight == 10) {
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                    } else {
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                    }
                }
                Toast.makeText(this, "Switching to light mode", Toast.LENGTH_SHORT).show()
                return true
            }
            R.id.notlightbulb -> {
                var darkorlight = -10
                val pref = SettingPref.getInstance(dataStore)
                val viewmodels =
                    ViewModelProvider(
                        this,
                        com.mobile.latihan.noteapp.ui.darkmode.ViewModelFactory(pref)
                    ).get(MyViewModel::class.java)
                viewmodels.getThemeSettings().observe(this) { isDarkMode: Boolean ->
                    if (darkorlight == -10) {
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                    } else {
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                    }
                }
                Toast.makeText(this, "Switching to dark mode", Toast.LENGTH_SHORT).show()
                return true
            } else -> super.onOptionsItemSelected(item)
        }
    }
}