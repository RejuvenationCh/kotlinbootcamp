package com.example.moviedatalibrary.Api

import com.example.moviedatalibrary.models.MovieResponse
import retrofit2.Call
import retrofit2.http.GET

interface ApiService {
    @GET("/3/movie/now_playing?api_key=cdc4fe13cb9eeddc5c7c9e625070f76f")
    fun getMovieNowPLaying(): Call<MovieResponse>

    @GET("/3/movie/popular?api_key=cdc4fe13cb9eeddc5c7c9e625070f76f")
    fun getMovieUpcoming(): Call<MovieResponse>

    @GET("/3/movie/top_rated?api_key=cdc4fe13cb9eeddc5c7c9e625070f76f")
    fun getMovieTopRated() : Call<MovieResponse>
}