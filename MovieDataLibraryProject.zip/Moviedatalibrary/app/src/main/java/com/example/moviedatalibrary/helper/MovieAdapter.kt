package com.example.moviedatalibrary.helper

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import androidx.navigation.Navigation.findNavController
import androidx.navigation.findNavController
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.bumptech.glide.Glide
import com.example.moviedatalibrary.R
import com.example.moviedatalibrary.databinding.ActivityMovieNavDrawBinding
import com.example.moviedatalibrary.models.Movie
import com.example.moviedatalibrary.ui.NowPlaying.FragmentNowPlaying
import kotlinx.android.synthetic.main.movie_cardview.view.*

class MovieAdapter (
    private val movies: List<Movie>) : RecyclerView.Adapter<MovieAdapter.MovieViewHolder>(){

    class MovieViewHolder(view: View) : ViewHolder(view){
        private val IMAGE_BASE = "https://image.tmdb.org/t/p/w500/"
        private lateinit var binding: ActivityMovieNavDrawBinding

        fun bindMovie(movie: Movie){
            itemView.movie_name.text = movie.title
            itemView.movie_date.text = movie.releaseDate
            itemView.move_description.text = movie.overview
            itemView.movie_rating.text = movie.voteAverage.toString()
            Glide.with(itemView).load(IMAGE_BASE + movie.posterPath).into(itemView.movie_poster)

        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        return MovieViewHolder(
            LayoutInflater.from(parent.context).inflate((R.layout.movie_cardview),parent,false)
        )
    }
    override fun getItemCount(): Int = movies.size
    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        holder.bindMovie(movies.get(position))
        }

    }
