package com.example.moviedatalibrary.ui.Upcoming

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.moviedatalibrary.Api.ApiConfig
import com.example.moviedatalibrary.Api.ApiService
import com.example.moviedatalibrary.helper.MovieAdapter
import com.example.moviedatalibrary.databinding.FragmentGalleryBinding
import com.example.moviedatalibrary.models.Movie
import com.example.moviedatalibrary.models.MovieResponse
import kotlinx.android.synthetic.main.fragment_gallery.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FragmentUpcoming : Fragment() {

    private var _binding: FragmentGalleryBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val galleryViewModel = ViewModelProvider(this).get(GalleryViewModel::class.java)
        _binding = FragmentGalleryBinding.inflate(inflater, container, false)
        val root: View = binding.root
        galleryViewModel.text.observe(viewLifecycleOwner) {
        }
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        rv_MovieUpcoming.apply {
            layoutManager = LinearLayoutManager(activity)
            rv_MovieUpcoming.setHasFixedSize(true)
            getUpcoming { movies : List<Movie> ->
                rv_MovieUpcoming.adapter = MovieAdapter(movies)
            }
        }
    }
    private fun getUpcoming(callback: (List<Movie>) -> Unit){
        val apiService = ApiConfig.getInstance().create(ApiService::class.java)
        apiService.getMovieUpcoming().enqueue(object : Callback<MovieResponse> {
            override fun onResponse(call: Call<MovieResponse>, response: Response<MovieResponse>) {
                return callback(response.body()!!.movies)
            }
            override fun onFailure(call: Call<MovieResponse>, t: Throwable) {
            }
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}