package com.example.moviedatalibrary.models

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize
import retrofit2.http.GET
import retrofit2.http.Query

data class MovieResponse (
    @SerializedName("results")
    val movies : List<Movie>)

