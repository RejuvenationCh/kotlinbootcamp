package com.example.moviedatalibrary.ui.darkmode

import android.content.Context
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.example.moviedatalibrary.R

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")
class darkmode : AppCompatActivity() {

    fun changedarkmode() {
        var darkorlight = 10
        val pref = SettingPref.getInstance(dataStore)
        val viewmodels =
            ViewModelProvider(
                this,
                ViewModelFactory(pref)
            ).get(DarkViewModel::class.java)
        viewmodels.getThemeSettings().observe(this) { isDarkMode: Boolean ->
            if (darkorlight == 10) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
        }
    }

    fun changelistmode() {
        var darkorlight = 10
        val pref = SettingPref.getInstance(dataStore)
        val viewmodels =
            ViewModelProvider(
                this,
                ViewModelFactory(pref)
            ).get(DarkViewModel::class.java)
        viewmodels.getThemeSettings().observe(this) { isDarkMode: Boolean ->
            if (darkorlight == 10) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
        }
    }
}

