package com.example.moviedatalibrary.ui.NowPlaying

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.moviedatalibrary.Api.ApiConfig
import com.example.moviedatalibrary.Api.ApiService
import com.example.moviedatalibrary.helper.MovieAdapter
import com.example.moviedatalibrary.databinding.FragmentHomeBinding
import com.example.moviedatalibrary.models.Movie
import com.example.moviedatalibrary.models.MovieResponse
import kotlinx.android.synthetic.main.fragment_home.rv_MovieList
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FragmentNowPlaying : Fragment() {

    private var layoutManager: RecyclerView.LayoutManager? = null
    private var adapter: RecyclerView.Adapter<MovieAdapter.MovieViewHolder>? = null
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val homeViewModel = ViewModelProvider(this).get(HomeViewModel::class.java)
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root
        homeViewModel.text.observe(viewLifecycleOwner) {
        }
        return root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        rv_MovieList.apply {
            layoutManager = LinearLayoutManager(activity)
            rv_MovieList.setHasFixedSize(true)
            getNowPlaying { movies : List<Movie> ->
                rv_MovieList.adapter = MovieAdapter(movies)

            }
        }
    }
    private fun getNowPlaying(callback: (List<Movie>) -> Unit){
        val apiService = ApiConfig.getInstance().create(ApiService::class.java)
        apiService.getMovieNowPLaying().enqueue(object : Callback<MovieResponse> {
            override fun onResponse(call: Call<MovieResponse>, response: Response<MovieResponse>) {
                return callback(response.body()!!.movies)
            }
            override fun onFailure(call: Call<MovieResponse>, t: Throwable) {
            }
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}